#include <QCoreApplication>
#include "settingsmanager.h"
#include "settingsmanager_global.h"
#define SILENT false
#define DEBUG true
float height;
float width;
float area;

SettingsManager * man;

void calculateArea()
{
    man->loadSettings();
    float area = man->valueAt(1)*man->valueAt(2); // height * width
    qDebug() << "Area is " <<  area;

}

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
    man = new SettingsManager("settings.txt");

    //! Save file first...
    //! demo of saving and adding settings
    //! settings can be of type double, float, int, QString, and anything QString can be cast to
    //    height =3; width=4;
    //    man->addSetting("REV","A");
    //    man->addSetting("height",height);
    //    man->addSetting("width",width);
    //    man->saveSettings();


    //! example 1.
    //! using a command line option to load a setting
    if(!strcmp(argv[1],"area")) calculateArea();;
    if(!strcmp(argv[1],"height")) qDebug() << man->valueAt(1);
    if(!strcmp(argv[1],"width")) qDebug() << man->valueAt(2);
    exit(0);






    //! example 2.
    //! demo of loading and printing settings
    //    man->loadSettings();
    //    man->printSettings();

    //! cast value of a QString variable to a QString like below
    //    qDebug() << man->nameAt(0) <<  QString(man->valueAt(0)); // prints the revision "A"

    //! you can specify the name of the setting by its index and the value the same way
    //        for(int i =0; i<man->count(); i++)
    //            qDebug() << man->nameAt(i) << man->valueAt(i);

    //! example 3.
    //! demo of using loaded values in a function
    //calculateArea();


    return a.exec();
}
